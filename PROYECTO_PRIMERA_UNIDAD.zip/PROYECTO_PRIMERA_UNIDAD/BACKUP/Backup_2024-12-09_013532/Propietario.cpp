#include "Propietario.h"

Propietario::Propietario(const string& nombre, const string& cedula, const string& correo)
    : nombre(nombre), cedula(cedula), correo(correo) {}
