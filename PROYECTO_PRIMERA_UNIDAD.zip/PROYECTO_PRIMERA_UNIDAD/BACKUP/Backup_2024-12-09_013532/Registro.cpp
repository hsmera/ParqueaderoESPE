#include "Registro.h"

Registro::Registro(const Auto& autoPermitido, const Propietario& propietario)
    : autoPermitido(autoPermitido), propietario(propietario) {}
