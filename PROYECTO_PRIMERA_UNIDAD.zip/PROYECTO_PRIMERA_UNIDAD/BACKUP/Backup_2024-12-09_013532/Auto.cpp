#include "Auto.h"

Auto::Auto(const string& placa, const string& marca, const string& color)
    : placa(placa), marca(marca), color(color) {}
